//
//  XK24HWModeViewController.m
//  XkeysViewer
//
//  Created by Ken Heglund on 11/10/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import "XK24HWModeViewController.h"

@interface XK24HWModeViewController ()

@end

@implementation XK24HWModeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.unitIDTextField.enabled = NO; //can set unitid in hardware mode just can't read it
    self.unitIDTextField.stringValue = @"";
    //self.outputbytesTextField.stringValue = @"B3 07 02";
}

@end

