//
//  XK24HWModeViewController.h
//  XkeysViewer
//
//  Coordinates the UI for an XK-24 with PID #2 (1028) or #4 (1249).
//
//  Created by Ken Heglund on 11/10/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import "XK24ViewController.h"

@interface XK24HWModeViewController : XK24ViewController

@end
