//
//  XKE124TBarHWModeViewController.m
//  XkeysViewer
//
//  Created by Ken Heglund on 11/10/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import "XKE124TBarHWModeViewController.h"

@interface XKE124TBarHWModeViewController ()

@end

@implementation XKE124TBarHWModeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.unitIDTextField.enabled = NO;
    self.unitIDTextField.stringValue = @"";
}

@end
