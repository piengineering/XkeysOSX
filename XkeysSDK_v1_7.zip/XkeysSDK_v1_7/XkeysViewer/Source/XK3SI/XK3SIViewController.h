//
//  XK3SIViewController.h
//  XkeysViewer
//
//  Coordinates the UI for an XK-3 Switch Interface with PID #1 (1221) or #4 (1224).
//
//  Created by Ken Heglund on 10/24/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import "XkeysDeviceViewController.h"

@class XK3SIState, XK3SIView;
@protocol Xkeys3SI;

NS_ASSUME_NONNULL_BEGIN

@interface XK3SIViewController : XkeysDeviceViewController

@property (nonatomic, readonly) id<Xkeys3SI> xkeys3SIDevice;
@property (nonatomic, readonly) XK3SIState *xkeys3SIState;
@property (nonatomic, readonly) XK3SIView *xkeys3SIView;

- (instancetype)initWithXkeysDevice:(id<XkeysDevice>)xkeysDevice NS_DESIGNATED_INITIALIZER;
- (instancetype)initWithNibName:(NSNibName _Nullable)nibNameOrNil bundle:(NSBundle * _Nullable)nibBundleOrNil xkeysDevice:(id<XkeysDevice>)xkeysDevice NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
