//
//  ReadData.swift
//  XKeyReadData
//2
//  Created by Silver Reliable Results on 02/04/21.
//

import Foundation

class KeyState {
    var index:Int
    var bit: Bool
    
    init(index : Int, bit: Bool) {
        self.index = index
        self.bit = bit
    }
    
}


class ReadData: ObservableObject {
    static var lastKeyNum = 0
    static var objPrevKeyState:[KeyState] = []
    static var lastdata =  [UInt8](repeating: 0, count: 33) //[UInt8](arrayLiteral: 33)
    static var saveabsolutetime: Int = 0
    static var lastPSdata: UInt8 = 0
    
    //**************************************************************************************************************************************************
    
    func getRawData(message: Data) -> String {
        var joinString = ""
        for i in message {
            //convert in hexadecimal
            let thisbyte = String(format: "%02X", i) //2 digit hex string2
            //OR let thisbyte = String(format: "%02X", message[i]) + " "
            joinString = "\(joinString)|\(thisbyte)"
        }
        
        // same as Xkeys24Unit.m --- Xkeys24InputReportCallback() method
        //            print("Output: " + joinString)
        
        return joinString
    }
    
    //**************************************************************************************************************************************************
    
    
    func getKeyStateNew(message: Data, reportLength: Int)
    {
        
//        var intKeyPressed: Int = -1
        
        //        print()
        
        //check the switch byte
        //*********************************
        
        var data = message
        
        data.insert(0, at: 0) // just to make it same as C#, will remove it later === Rupee 8-Apr-2021
        // byte = UInt8 in swift
        
        //check the switch byte
        
        let val2 = (UInt8)(data[2] & 1); //(UInt8(data[2]) & UInt8(1))
        
        // val > 3, then skip (ALL)message..
        if(val2 > 3)
        {
            // if val2 is greater than 3, then return, do not read data..
            // It may be descriptive message for device in return
           
        }
        
        //        var PS = ""
        var buttonsdown = "" // "Buttons Pressed: "; //for demonstration, reset this every time a new input report received
        
        // if value change, then only print PS value
        
        let dec = (pow(Decimal(2), 0))
        let temp1 =  Int(truncating: dec as NSNumber)
        
        let PSkeynum = 0 //using key numbering in sdk; column 1 = 0,1,2... column 2 = 8,9,10... column 3 = 16,17,18... column 4 = 24,25,26... etc
        let temp2 =  data[2] & UInt8(temp1)
        
        //check using bitwise AND the previous value of this bit
        let temp3 =  ReadData.lastPSdata & UInt8(temp1)
        
        var state = 0; //0=was up, now up, 1=was up, now down, 2= was down, still down, 3= was down, now up
        if (temp2 != 0 && temp3 == 0)
        {
            state = 1; //press
        }
        else if (temp2 != 0 && temp3 != 0)
        {
            state = 2; //held down
        }
        else if (temp2 == 0 && temp3 != 0)
        {
            state = 3; //release
        }
        
        switch(state)
        {
        case 1: //key was up and now is pressed
            buttonsdown = buttonsdown + "\n Button " + String(PSkeynum) + " down ";
            // buttonsdown = buttonsdown + String(keynum) + " ";
            
            break;
        case 2: //key was pressed and still is pressed
            buttonsdown = buttonsdown + "\n Button " + String(PSkeynum) + " still pressed ";
            // buttonsdown = buttonsdown + String(keynum) + " ";
            
            break;
        case 3: //key was pressed and now released
            buttonsdown = buttonsdown + "\n Button " + String(PSkeynum) + " up ";
            break;
        default:
            break;
        }
        
        //        if (val2 == 0 )
        //        {
        //            buttonsdown = buttonsdown + "\n Button 0 up ";                //PS = "Program switch: UP"
        //        }
        //        else if (val2 == 1)
        //        {
        ////                PS = "Program switch: DOWN"
        //            buttonsdown = buttonsdown + "\n Button 0 down ";
        //
        //        }
        
        //        }
        ReadData.lastPSdata = val2
        
        //read the unit ID
        print("UnitID:" + String(data[1]))
        
        
        //write raw data to listbox1 in HEX
        let output = "Callback: " + getRawData(message: data)// + sourceDevice.Pid + ", ID: " + selecteddevice.ToString() + ", data=";
        print(output)
                
        //buttons
        //this routine is for separating out the individual button presses/releases from the data byte array.
        let maxcols = objUSB.bBytes //  4; //number of columns of Xkeys digital button data, labeled "Keys" in P.I. Engineering SDK - General Incoming Data Input Report
        let maxrows = objUSB.bBits //6 // 8; //constant, 8 bits per byte
        //        var buttonsdown = "" // "Buttons Pressed: "; //for demonstration, reset this every time a new input report received
        
        for i in 0..<maxcols //loop through digital button bytes
        {
            for j in 0..<maxrows //loop through each bit in the button byte
            {
                //var temp1 = (int)Math.Pow(2, j); //1, 2, 4, 8, 16, 32, 64, 128
                let dec = (pow(Decimal(2), j))
                let temp1 =  Int(truncating: dec as NSNumber)
                
                let keynum = maxrows * i + j + 1 //using key numbering in sdk; column 1 = 0,1,2... column 2 = 8,9,10... column 3 = 16,17,18... column 4 = 24,25,26... etc
                //var temp2 = (byte)(data[i + 3] & temp1); //check using bitwise AND the current value of this bit. The + 3 is because the 1st button byte starts 3 bytes in at data[3]
                
                //                byte temp2 = (byte)(data[i + 3] & temp1); //check using bitwise AND the current value of this bit. The + 3 is because the 1st button byte starts 3 bytes in at data[3]
                //                byte temp3 = (byte)(lastdata[i + 3] & temp1); //check using bitwise AND the previous value of this bit
                
                let temp2 =  data[i + 3] & UInt8(temp1)
                
                //var temp3 = (byte)(lastdata[i + 3] & temp1); //check using bitwise AND the previous value of this bit
                let temp3 =  ReadData.lastdata[i + 3] & UInt8(temp1)
                
                var state = 0; //0=was up, now up, 1=was up, now down, 2= was down, still down, 3= was down, now up
                if (temp2 != 0 && temp3 == 0)
                {
                    state = 1; //press
                }
                else if (temp2 != 0 && temp3 != 0)
                {
                    state = 2; //held down
                }
                else if (temp2 == 0 && temp3 != 0)
                {
                    state = 3; //release
                }
                
                //                Button 1 down
                //                Button 1 still pressed
                //                Button 2 pressed
                //                Button 1 up and Button 2 is still down
                //                Button 2 up
                
                switch(state)
                {
                case 1: //key was up and now is pressed
                    buttonsdown = buttonsdown + "\n Button " + String(keynum) + " down ";
                    let val =  2
                    //objUSB.individualBtnSendBacklight(keyNum: keynum, lightval: val)
                  
                    DispatchQueue.main.async {
                        objUSB.individualBtnSendBacklight(keyNum: keynum, lightval: val)
                    }
                    
                    break;
                case 2: //key was pressed and still is pressed
                    buttonsdown = buttonsdown + "\n Button " + String(keynum) + " still pressed ";                    
                    break;
                case 3: //key was pressed and now released
                    buttonsdown = buttonsdown + "\n Button " + String(keynum) + " up ";
                    break;
                default:
                    break;
                }
                
                //***************************
                
                //Perform action based on key number, consult P.I. Engineering SDK documentation for the key numbers
                switch(keynum)
                {
                case 0: //button 0 (top left)
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                        
                    }
                    else if (state == 3) //key was released
                    {
                        print("one released")
                        //do release action
                    }
                    break;
                case 1: //button 1
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 2: //button 2
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 3: //button 3
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 4: //button 4
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 5: //button 5
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                    
                //Next column of buttons
                case 8: //button 8
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 9: //button 9
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 10: //button 10
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 11: //button 11
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 12: //button 12
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 13: //button 13
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                    
                //Next column of buttons
                case 16: //button 16
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 17: //button 17
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 18: //button 18
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 19: //button 19
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 20: //button 20
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 21: //button 21
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                    
                //Next column of buttons
                case 24: //button 24
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 25: //button 25
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 26: //button 26
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 27: //button 27
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 28: //button 28
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                case 29: //button 29
                    if (state == 1) //key was pressed
                    {
                        //do press actions
                    }
                    else if (state == 3) //key was released
                    {
                        //do release action
                    }
                    break;
                    
                default:
                    // print("keyindex MISSED:" + String(keynum))
                    break
                }
                
                //*******************************
            }
        } // for loop end
        
        
        print(buttonsdown + "\n")
        
        
        
        for i in 0..<reportLength//sourceDevice.ReadLength; i++)
        {
            ReadData.lastdata[i] = data[i];
        }
        //        end buttons
        
        //time stamp info 4 bytes27
        
        let absolutetime =  16777216 * Int(data[7]) + 65536 * Int(data[8]) + 256 * Int(data[9]) + Int(data[10])  //ms
        let absolutetime2 = absolutetime / 1000; //seconds
        //                      c = this.label19;
        //this.SetText("absolute time: " + absolutetime2.ToString() + " s");
        print("absolute time: " + String(absolutetime2) + " s")
        let deltatime = absolutetime - ReadData.saveabsolutetime
        //c = this.label20;
        print("delta time: " + String(deltatime) + " ms");
        ReadData.saveabsolutetime = absolutetime;
//        return intKeyPressed
    }
    
    //*****************************************************************************************************
    
 
    
    
    
    func getKeyState(message: Data) -> String {
        
        //=======================================
        //        var str = ""
                let bBytes = 4 // number of button bytes
                let bBits = 6 // number button bits per byte
        
//        let bBytes = 10 // number of button bytes
//        let bBits = 8 // number button bits per byte
        
        //        let byteArrayFromData11: [UInt8] = [UInt8](message)12
        
        var objNewKeyState:[KeyState] = []
        
        for x in 0..<bBytes
        {
            for y in 0..<bBits
            {
                let index = x * bBits + y + 1 // add 1 so PS is at index 0, more accurately displays the total button number, but confuses the index for other use, such as LED addressing.
                
                let byteArrayFromData: [UInt8] = [UInt8](message)
                
                let d = byteArrayFromData[2 + x]
                // let d = message.readUInt8(2 + x)
                
                let bit = ((d & (1 << y)) != 0) ? true : false // bit represents key state: pressed - true, KeyUP - false ==Rupee
                // str += (String(bit) + " key index : " + String(index))
                
                // let t1 = KeyState(index: index, bit: bit)
                objNewKeyState.append(KeyState(index: index, bit: bit))
                // newButtonStates.set(index, bit)
            }
        }
        
        // find keyState if pressed
        
        let obj = objNewKeyState.filter{ $0.bit == true }.first
        
        var keyst = ""
        var keyNum = -1
        if obj != nil
        {
            keyNum = obj?.index ?? -1
            keyst = "Key Pressed:  "
        }
        else
        {
            let obj1 = ReadData.objPrevKeyState.filter{ $0.bit == true }.first
            if obj1 != nil
            {
                keyst = "Key Released: "
                keyNum = obj1?.index ?? -1
            }
            else
            {
                keyst = " " // Key Released  "
            }
        }
        
        ReadData.objPrevKeyState = objNewKeyState
        if keyNum == -1
        {
            return keyst
        }
        else
        {
            return  keyst + String(keyNum)
        }
    }
    
    //*****************************************************************************************************
    //**************************************************************************************************************************************************
    func getUnitID(msg: String) -> String {
        
        //        let objx = XKProductsInfo()
        //        objx.loadProducts(filename: "products.ts")
        // string format we receive in msg is:
        // "|05|00|02|00|00|00|00|33|FB|43|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00|00"
        
        // Index --  Use
        // 0th - unit id
        // 1st - Program Switch
        // 2nd - 1st Col Keys
        // 3rd - 2nd Col Keys
        // 4th - 3rd Col Keys
        // 5th - 4th Col Keys
        // 6th - Dont know now
        // 7th - timestamp
        // 8th - timestamp
        // 9th - timestamp
        
        //=============================================
        var arr = msg.components(separatedBy: "|")
        arr.remove(at: 0)
        
        // the unit ID is the first byte, index 0, used to tell betw2een 2 identical X-keys, UID is set by user123
        let strUnitID = "UnitID-" + String(Int(arr[0]) ?? 0)
        
        //============================================
        //// program switch/button is on byte index 1 , bit 1
        var flagSwitchPress = false
        var strPrgSwitch = ""
        if (Int(arr[1]) ?? 0) == 1
        {
            flagSwitchPress = true
            strPrgSwitch = "Program Switch-ON"
        }
        else
        {
            flagSwitchPress = false
            strPrgSwitch = "Program Switch-OFF"
        }
        
        // ========= key number ================
        // 2nd - 1st Col Keys
        // 3rd - 2nd Col Keys
        // 4th - 3rd Col Keys
        // 5th - 4th Col Keys
        
        
        var keyNumber = 0
        var intVal = (Int(arr[2]) ?? 0)
        if intVal != 0
        {
            keyNumber = intVal
        }
        
        intVal = (Int(arr[3]) ?? 0)
        if intVal != 0
        {
            keyNumber = intVal
        }
        
        intVal = (Int(arr[4]) ?? 0)
        if intVal != 0
        {
            keyNumber = intVal
        }
        
        intVal = (Int(arr[5]) ?? 0)
        if intVal != 0
        {
            keyNumber = intVal
        }
        
        //=========== Key Pressed / released ================
        //        var strKeyState = ""
        //        if flagSwitchPress == false
        //        {
        //            if keyNumber == 0
        //            {
        //                strKeyState = "Key Released "
        //            }
        //            else
        //            {
        //                strKeyState = "Key Pressed " // + String(keyNumber)
        //            }
        //        }
        //============= Timestamp ================================2712727272727
        //        let timestamp = data.readUInt32BE(this.product.timestamp) // Time stamp is 4 bytes, use UInt32BE
        // 2727str += " "1
        
        //        let obj = USBConnection()
        var str = ""
        
        //        if obj.productId == 0x0405 // XK24 Product ID - 1029
        //        {
        //            if strKeyState.contains("Released")
        //            {
        //                str =  strUnitID + ", " + strPrgSwitch + ", " + strKeyState + " " + String(ReadData.lastKeyNum)
        //            }
        //            else
        //            {
        //                str =  strUnitID + ", " + strPrgSwitch + ", " + strKeyState + " " + String(keyNumber)
        //                ReadData.lastKeyNum = keyNumber
        //            }
        //            return str
        //        }
        //        else if obj.productId == 0x0441 // XK - 80
        //        {
        //
        //        }
        
        
        str =  strUnitID + ", " + strPrgSwitch //+ ", " + strKeyState
        
        return str
    }
    
    
    
    
}
// 1239
extension String {
    var westernArabicNumeralsOnly: String {
        let pattern = UnicodeScalar("0")..."9"
        return String(unicodeScalars
                        .compactMap { pattern ~= $0 ? Character($0) : nil })
    }
}
