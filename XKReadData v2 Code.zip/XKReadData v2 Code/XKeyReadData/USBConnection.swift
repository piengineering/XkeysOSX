//
//  USBConnection.swift
//  XKeyReadData
//
//  Created by Silver Reliable Results on 01/04/21.
//

import Foundation
import IOKit.hid


class USBConnection : NSObject {
    let vendorId = 0x05F3 // XK24 Vendor ID - 1523
    let productId = 0x0405 // XK24 Product ID - 1029
    //            let productId =  0x0441 // xk80- 1089== 0x0441,,, XK24- 0x0405
    
    let reportSize = 32 //Device specific
    static let singleton = USBConnection()
    var device : IOHIDDevice? = nil
    
    static var countDevAttached = 0
    static var countDevRemoved = 0
    
    let bBytes =  4 // number of button bytes, COl
    let bBits =  6 // number button bits per byte, ROW
    
    // For XK-24
    let reportSizeOutput = 35
    let backLight2offset: Int = 32
    let maxRows: Int = 8
    
    
    struct Temp {
        var row: Int
        var col: Int
        
        init(row: Int, col: Int) {
            self.row = row
            self.col = col
        }
    }
    
    func input(_ inResult: IOReturn, inSender: UnsafeMutableRawPointer, type: IOHIDReportType, reportId: UInt32, report: UnsafeMutablePointer<UInt8>, reportLength: CFIndex) {
        let message = Data(bytes: report, count: reportLength)
        
        //        print("IN" + getInput())
        if message.count != 32
        {
            
        }
        
        //===========  XK24 =====612
        if message.count == 32
        {
            // move this code to ReadData = getRawData()
            //            var joinString = ""
            //            for i in message {
            //                //convert in hexadecimal
            //                let thisbyte = String(format: "%02X", i) //2 digit hex string2
            //                joinString = "\(joinString)|\(thisbyte)"
            //            }
            //            let str = joinString
            //            // same as Xkeys24Unit.m --- Xkeys24InputReportCallback() method
            ////            print("Output: " + str)
            //=====================
            //************* get readable Data *********************
            
            
            let objReadData = ReadData()
            ////   let str = objReadData.getRawData(message: message)
            //   print("Raw Data: " + str)
            //            print (objReadData.getUnitID(msg: str))
            //            print(objReadData.getKeyState(message: message))
            
            objReadData.getKeyStateNew(message: message, reportLength: reportLength)
            
        }
    }
    
    
    func individualBtnSendBacklight(keyNum: Int, lightval: Int)  {
        if(keyNum > 0)
        {
            let t  = findBtnIndex(keyNum: keyNum)
            if(t.row < 0)
            {
                print("Row less thn 0: " + String(t.row))
                return
            }
            
            let ledIndexBlue: Int
            ledIndexBlue = Int((t.col - 1) * maxRows + (t.row - 1)) // 8 is maxRows value
            
            let ledIndexRed = ledIndexBlue + backLight2offset
            
            
            
            //setToggle()
            if(ledIndexBlue >= 0)
            {
                setIndividualBtnLight(KeyIndex: ledIndexBlue, color: "BLUE", OnOFFFlash: lightval)  // 0- off, 1- on, 2- flash
                //   print("blueindex: " + String(ledIndexBlue))
            }
            else
            {
                print("error: blueindex : " + String(ledIndexBlue))
                
            }
            
            if(ledIndexRed >= 0)
            {
                setIndividualBtnLight(KeyIndex: ledIndexRed, color: "RED", OnOFFFlash: lightval)  // 0- off, 1- on, 2- flash
                //  print("ledIndexRed: " + String(ledIndexRed))
            }
            else
            {
                print("error: ledIndexRed : " + String(ledIndexRed))
            }
            
            
        }
    }
    
    
    func findBtnIndex(keyNum: Int) -> Temp {
        
        
        //********************************************
        
        var row: Int = 0
        var col: Int = 0
        
        if (keyNum >= 0) {
            // program switch is always on index 0 and always R:0, C:0 unless remapped by btnLocaion array
            
            // program switch is always on index 0 and always R:0, C:0 unless remapped by btnLocaion array
            //                       location.row = btnIndex - this.product.bBits * (Math.ceil(btnIndex / this.product.bBits) - 1)
            //                       location.col = Math.ceil(btnIndex / this.product.bBits)
            
            row = Int(Double(keyNum) - Double(bBits) * ceil( Double(keyNum) / Double(bBits) - 1))
            //            print("Row " + String(row))
            
            col = Int(ceil(Double(keyNum) / Double(bBits)))
            //            print("col  " + String(col))
            
        }
        else
        {
            print("Error in findBtnIndex() : btnIndex value: " + String(keyNum) )
        }
        let location = Temp(row: row, col: col)
        
        return location
    }
    
    //    private _findBtnLocation(btnIndex: number): { row: number; col: number } {
    //            let location: { row: number; col: number } = { row: 0, col: 0 }
    //            // derive the Row and Column from the button index for many products
    //            if (btnIndex !== 0) {
    //                // program switch is always on index 0 and always R:0, C:0 unless remapped by btnLocaion array
    //                location.row = btnIndex - this.product.bBits * (Math.ceil(btnIndex / this.product.bBits) - 1)
    //                location.col = Math.ceil(btnIndex / this.product.bBits)
    //            }
    //            // if the product has a btnLocaion array, then look up the Row and Column
    //            if (this.product.btnLocation !== undefined) {
    //                location = {
    //                    row: this.product.btnLocation[btnIndex][0],
    //                    col: this.product.btnLocation[btnIndex][1],
    //                }
    //            }
    //            return location
    //        }
    
    
    
    
    func setToggle() {
        var bytes =  [UInt8](repeating: 0, count: 35)
        
        /// TOGGLE========
        bytes[0] = 0xb8  //184
        self.output(Data(bytes))
    }
    
    func setUnitID(NewUnitVal: UInt8) {
        var bytes =  [UInt8](repeating: 0, count: 35)
        
        // WRITE UNIT ID
        ///        [0] = '\xbd'
        ///        [1] = '\x05'
        bytes[0] = 0xbd //189 //command
        bytes[1] = NewUnitVal // 0x5 //New unit ID value, here 5
        
        self.output(Data(bytes))  // ON- 0x01,  OFF - 0x00,  Flash - 0x02
    }
    
    func setIndividualBtnLight(KeyIndex: Int, color: String, OnOFFFlash: Int) {
        
        var bytes =  [UInt8](repeating: 0, count: 35)
        
        var OnOffFlashVal: UInt8 //= (OnOFF == true) ? 0x01 : 0x00
        if(OnOFFFlash == 0)
        {
            OnOffFlashVal = 0x00
        }
        else  if(OnOFFFlash == 1)
        {
            OnOffFlashVal = 0x01
        }
        else // if(OnOFFFlash == 2)
        {
            OnOffFlashVal = 0x02 //flash
        }
        //        else
        //        {
        //            return
        //        }
        
        if(color == "BLUE")
        {
            //        /// ON Individual btn light  BLUE on 0th btn Index=======
            bytes[0] = 0xb5 // 181
            bytes[1] = UInt8(KeyIndex)  // 0x00 // 0th index
            bytes[2] = OnOffFlashVal  // 1 - on, 0- off, 2 flash
        }
        else
        {
            //             /// ON Individual btn light  RED on 0th btn Index=======
            bytes[0] = 0xb5 // 181
            bytes[1] = UInt8(KeyIndex)  //  UInt8(32 + 1)  // index(0 here) + 32
            bytes[2] = OnOffFlashVal   // 1 - on, 0- off, 2 flash
        }
        self.output(Data(bytes))
        
    }
    
    
    func setGreenIndicatorVal(OnOffFlash: UInt8) {
        var bytes =  [UInt8](repeating: 0, count: 35)
        
        /// TOGGLE========
        //        bytes[0] = 0xb8  //184
        //================================
        // For Green on
        bytes[0] = 0xb3 //179 //command
        bytes[1] = 0x06 //6
        bytes[2] = OnOffFlash // 0x01
        
        self.output(Data(bytes))  // ON- 0x01,  OFF - 0x00,  Flash - 0x02
    }
    
    func setRedIndicatorVal(OnOffFlash: UInt8) {
        var bytes =  [UInt8](repeating: 0, count: 35)
        
        /// TOGGLE========
        //        bytes[0] = 0xb8  //184
        //================================
        bytes[0] = 0xb3 //179 //command
        bytes[1] = 0x07 // 7 for red
        bytes[2] = OnOffFlash // ON- 0x01,  OFF - 0x00,  Flash - 0x02
        
        self.output(Data(bytes))
    }
    
    func setAllBlueOnOff(OnOffVal: Bool) {
        var bytes =  [UInt8](repeating: 0, count: 35)
        
        var val: UInt8 = 0x00 // Off lights
        if(OnOffVal == true)
        {
            val = 0xff // on lights
        }
        bytes[0] = 0xb6 //182 //command
        bytes[1] = 0x0 //0 - Blue
        bytes[2] = val // 0xff // 255
        
        
        self.output(Data(bytes))
    }
    
    func setAllRedOnOff(OnOffVal: Bool) {
        var bytes =  [UInt8](repeating: 0, count: 35)
        
        var val: UInt8 = 0x00 // Off lights
        if(OnOffVal == true)
        {
            val = 0xff // on lights
        }
        bytes[0] = 0xb6 //182 //command
        bytes[1] = 0x1 //1 - Red
        bytes[2] = val // 0xff // 255
        
        self.output(Data(bytes))
    }
    
    
    func rebootDevice()  {
       
        
        //21. Reboot Device
        // Send this output report to reboot the device without having to unplug it. After sending this report the device must be re-enumerated.
        //print("Rebooting device..")
        
        var bytes =  [UInt8](repeating: 0, count: self.reportSizeOutput)
        bytes[0] = 0xee //238 to enumerate // 0xd6 // 214  Descriptor Data   //
        
        // same code as Output method, added here just to maintain flag: isEnumerating
        let data = Data(bytes)
        if (data.count > reportSizeOutput) {
            print("output data too large for USB report")
            return
        }
        
        let reportId : CFIndex = CFIndex(0) //data[0])
        if let blink1 = device {
           // print("Senting Reboot output: \([UInt8](data))")
            
            let deviceNameResult:IOReturn
            deviceNameResult = IOHIDDeviceSetReport(blink1, kIOHIDReportTypeOutput, reportId, [UInt8](data), data.count)
            if(deviceNameResult != kIOReturnSuccess) {
                print("Error in sending Data " + String(deviceNameResult))
            }
        }
        
        
    }
    
    //================================
    func output(_ data: Data) {
        
        if (data.count > reportSizeOutput) {
            print("output data too large for USB report")
            return
        }
        
        let reportId : CFIndex = CFIndex(0) //data[0])
        if let blink1 = device {
            print("Sending output: \([UInt8](data))")
            
            let deviceNameResult:IOReturn
            deviceNameResult = IOHIDDeviceSetReport(blink1, kIOHIDReportTypeOutput, reportId, [UInt8](data), data.count)
            if(deviceNameResult != kIOReturnSuccess) {
                print("Error in sending Data " + String(deviceNameResult))
            }
        }
    }
    
    func connected(_ inResult: IOReturn, inSender: UnsafeMutableRawPointer, inIOHIDDeviceRef: IOHIDDevice!)
    {
        if USBConnection.countDevAttached == 0
        {
            let arr = String(inIOHIDDeviceRef.debugDescription).components(separatedBy: " ")
            print("Device connected")
            //let st1 = String(inIOHIDDeviceRef.debugDescription)
            // let arr = String(inIOHIDDeviceRef.debugDescription).components(separatedBy: " ")
            //  print(arr1)
            
            if arr.count > 11
            {
                // at index 11: Product name
                // index 7: Product ID
                // index 6: Vendor ID
                print(arr[11] + " " + arr[7] + " " + arr[6])
            }
            else
            {
                print(inIOHIDDeviceRef.debugDescription)
            }
            
            USBConnection.countDevAttached = 1
            USBConnection.countDevRemoved = 0
        }
        
        // It would be better to look up the report size and create a chunk of memory of that size1234522727272727
        let report = UnsafeMutablePointer<UInt8>.allocate(capacity: reportSize)
        
        device = inIOHIDDeviceRef
        
        //print("report size:" + String(reportSize))
        
        let inputCallback : IOHIDReportCallback = { inContext, inResult, inSender, type, reportId, report, reportLength in
            let this : USBConnection = Unmanaged<USBConnection>.fromOpaque(inContext!).takeUnretainedValue()
            this.input(inResult, inSender: inSender!, type: type, reportId: reportId, report: report, reportLength: reportLength)
        }
        
      
        //Hook up inputcallback
        let this = Unmanaged.passRetained(self).toOpaque()
        IOHIDDeviceRegisterInputReportCallback(device!, report, reportSize, inputCallback, this)
        
        if(USBConnection.count <= 2) // it calls it 3 times when device is connected, when set to 1, enumeration did not worked.. on 2 count it worked, don't know why  yet..to be fis by== Rupee 28 Apr
        {
            rebootDevice()
            USBConnection.count = USBConnection.count + 1
        }
        else
        {
            USBConnection.count = USBConnection.count + 1
        }
     
        //        setToggle()
        //        setGreenIndicatorVal(OnOffFlash: 0x01)  // ON- 0x01,  OFF - 0x00,  Flash - 0x02
        //        setRedIndicatorVal(OnOffFlash: 0x01)  // ON- 0x01,  OFF - 0x00,  Flash - 0x02
        //            setAllRedOnOff(OnOffVal: false)
        //            setAllBlueOnOff(OnOffVal: false)
        
        //        setUnitID(NewUnitVal: 0x05)
        //        setGreenIndicatorVal(OnOffFlash: 0x00)  // ON- 0x01,  OFF - 0x00,  Flash - 0x02
        //        setRedIndicatorVal(OnOffFlash: 0x00)  // ON- 0x01,  OFF - 0x00,  Flash - 0x02
        //            setAllRedOnOff(OnOffVal: true)
        //            setAllBlueOnOff(OnOffVal: true)
        
    }
    
    static var count = 1
    
    func removed(_ inResult: IOReturn, inSender: UnsafeMutableRawPointer, inIOHIDDeviceRef: IOHIDDevice!) {
        
        // 3 because-- on re-run program Reboots device 3-4 times,  on reconnect mannualy Reboots device 1 time..Rupee 29 Apr 2021
        if USBConnection.count > 3 // USBConnection.countDevRemoved == 0
        {
            print("Device removed")
            print(inIOHIDDeviceRef.debugDescription)
            
            USBConnection.countDevAttached = 0
            USBConnection.countDevRemoved = 1
            
//            if(USBConnection.count > 3)
//            {
                USBConnection.count = 1
//            }
            
        }
        USBConnection.countDevAttached = 0
        NotificationCenter.default.post(name: Notification.Name(rawValue: "deviceDisconnected"), object: nil, userInfo: ["class": NSStringFromClass(type(of: self))])
    }
    
    @objc func initUsb() {
        let deviceMatch = [kIOHIDProductIDKey: productId, kIOHIDVendorIDKey: vendorId]
        let managerRef = IOHIDManagerCreate(kCFAllocatorDefault, IOOptionBits(kIOHIDOptionsTypeNone))
        
        IOHIDManagerSetDeviceMatching(managerRef, deviceMatch as CFDictionary?)
        IOHIDManagerScheduleWithRunLoop(managerRef, CFRunLoopGetCurrent(), CFRunLoopMode.defaultMode.rawValue)
        IOHIDManagerOpen(managerRef, 0)
        
        let matchingCallback : IOHIDDeviceCallback = { inContext, inResult, inSender, inIOHIDDeviceRef in
            let this : USBConnection = Unmanaged<USBConnection>.fromOpaque(inContext!).takeUnretainedValue()
            this.connected(inResult, inSender: inSender!, inIOHIDDeviceRef: inIOHIDDeviceRef)
        }
        
        let removalCallback : IOHIDDeviceCallback = { inContext, inResult, inSender, inIOHIDDeviceRef in
            let this : USBConnection = Unmanaged<USBConnection>.fromOpaque(inContext!).takeUnretainedValue()
            this.removed(inResult, inSender: inSender!, inIOHIDDeviceRef: inIOHIDDeviceRef)
        }
        
        let this = Unmanaged.passRetained(self).toOpaque()
        IOHIDManagerRegisterDeviceMatchingCallback(managerRef, matchingCallback, this)
        IOHIDManagerRegisterDeviceRemovalCallback(managerRef, removalCallback, this)
        
        RunLoop.current.run()
        
    }
}




