//
//  AppDelegate.h
//  XkeysViewer
//
//  Created by Ken Heglund on 10/24/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class XkeysRootViewController;

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (nonatomic) IBOutlet NSWindowController *windowController;

@end
