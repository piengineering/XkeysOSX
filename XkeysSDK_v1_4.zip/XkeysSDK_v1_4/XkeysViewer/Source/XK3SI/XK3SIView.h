//
//  XK3SIView.h
//  XkeysViewer
//
//  Provides drawing specific to the XK-3 Switch Interface.
//
//  Created by Ken Heglund on 10/24/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

@import Cocoa;

#import "XkeysDeviceView.h"

@interface XK3SIView : XkeysDeviceView

//- (void)invalidateTbar;

@end
