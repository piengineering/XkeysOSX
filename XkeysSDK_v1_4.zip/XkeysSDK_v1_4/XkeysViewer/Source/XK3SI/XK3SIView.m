//
//  XK3SIView.m
//  XkeysViewer
//
//  Created by Ken Heglund on 10/24/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import "XK3SIState.h"

#import "XK3SIView.h"

@implementation XK3SIView

// MARK: - XkeysDeviceView overrides

+ (NSInteger)buttonColumnCount {
    
    return 16;
}

+ (NSInteger)buttonRowCount {
    return 8;
}

- (NSInteger)buttonNumberAtLocation:(NSPoint)locationInView inFrame:(NSRect)controlFrame {
    
    NSInteger buttonNumber = [super buttonNumberAtLocation:locationInView inFrame:controlFrame];
    
    if ( ![self.deviceState isValidButtonNumber:buttonNumber] ) {
        return NSNotFound;
    }
    
    return buttonNumber;
}

- (void)drawControlOverlayInFrame:(NSRect)controlFrame { //don't draw t-bar
    
//    XK3SIState *tbarState = (XK3SIState *)self.deviceState;
//    NSAssert([tbarState isKindOfClass:[XK3SIState class]], @"");
    
//    [[self class] drawTbarState:tbarState inFrame:controlFrame];
}

// MARK: - XK3SIView implementation

//- (void)invalidateTbar {
    
//    NSRect deviceFrame = [[self class] calculateDeviceFrameWithinBounds:self.bounds];
//    NSRect controlFrame = [[self class] calculateControlFrameInDevice:deviceFrame];
//    NSRect tbarFrame = [XK3SIView calculateTbarFrameInFrame:controlFrame];
    
//    [self setNeedsDisplayInRect:tbarFrame];
//}

// MARK: - XK3SIView internal

//+ (NSRect)calculateTbarFrameInFrame:(NSRect)controlFrame {
    
    // The t-bar occupies the area where buttons 108-111 would be
    
//    NSRect topFrame = [[self class] calculateButtonFrame:108 inFrame:controlFrame];
//    NSRect bottomFrame = [[self class] calculateButtonFrame:111 inFrame:controlFrame];
//    NSRect tbarFrame = NSUnionRect(topFrame, bottomFrame);

//    return tbarFrame;
//}

//+ (void)drawTbarState:(XK3SIState *)deviceState inFrame:(NSRect)controlFrame {
    
//    NSRect tbarFrame = [XK3SIView calculateTbarFrameInFrame:controlFrame];
    
//    [[NSColor colorWithCalibratedWhite:0.25 alpha:1.0] set];
//    NSRectFill(tbarFrame);
    
//    CGFloat borderOffset = XkeysDeviceViewOutlineThickness / 2.0;
//    NSPoint bottomLeft = (NSPoint){ .x = NSMinX(tbarFrame) + borderOffset, .y = NSMinY(tbarFrame) };
//    NSPoint topLeft = (NSPoint){ .x = NSMinX(tbarFrame) + borderOffset, .y = NSMaxY(tbarFrame) - borderOffset };
//    NSPoint topRight = (NSPoint){ .x = NSMaxX(tbarFrame) - borderOffset, .y = NSMaxY(tbarFrame) - borderOffset };
//    NSPoint bottomRight = (NSPoint){ .x = NSMaxX(tbarFrame) - borderOffset, .y = NSMinY(tbarFrame) };
    
//    NSBezierPath *path = [[NSBezierPath alloc] init];
//    path.lineWidth = XkeysDeviceViewOutlineThickness;
//    [path moveToPoint:bottomLeft];
//    [path lineToPoint:topLeft];
//    [path lineToPoint:topRight];
//    [path lineToPoint:bottomRight];
    
//    [[NSColor blackColor] set];
//    [path stroke];
    
//    // Vertical slider slot
    
//    NSRect sliderFrame = NSInsetRect(tbarFrame, tbarFrame.size.width * 0.1, tbarFrame.size.height * 0.1);
    
//    const CGFloat minSlotThickness = 2.0;
//    NSRect slotFrame = sliderFrame;
//    slotFrame.size.width = MAX(sliderFrame.size.width * 0.1, minSlotThickness);
//    slotFrame.origin.x = NSMidX(sliderFrame) - (slotFrame.size.width / 2.0);
//
//    [[NSColor colorWithCalibratedWhite:0.5 alpha:1.0] set];
//    NSRectFill(slotFrame);
//
//    // Horizontal indicator
//
//    CGFloat positionAsPercent = (CGFloat)( deviceState.currentTbarPosition - deviceState.minTbarPosition ) / (CGFloat)( deviceState.maxTbarPosition - deviceState.minTbarPosition );
//
//    const CGFloat minIndicatorHeight = 2.0;
//    NSRect indicatorFrame = (NSRect){
//        .origin.x = sliderFrame.origin.x,
//        .origin.y = NSMinY(sliderFrame) + (sliderFrame.size.height * positionAsPercent),
//        .size.width = sliderFrame.size.width,
//        .size.height = MAX(sliderFrame.size.height * 0.05, minIndicatorHeight)
//    };
//
//    indicatorFrame.origin.y -= ( indicatorFrame.size.height / 2.0 );
//
//    [[NSColor colorWithCalibratedWhite:0.75 alpha:1.0] set];
//    NSRectFill(indicatorFrame);
//}

@end
