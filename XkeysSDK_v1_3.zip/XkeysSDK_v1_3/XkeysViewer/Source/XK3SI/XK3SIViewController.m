//
//  XK3SIViewController.m
//  XkeysViewer
//
//  Created by Ken Heglund on 10/24/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

@import XkeysKit;

#import "XK3SIState.h"
#import "XK3SIView.h"

#import "XK3SIViewController.h"

static NSString * const Xkeys3SIVC_keyPath_greenLEDStateTag = @"greenLEDStateTag";
static NSString * const Xkeys3SIVC_keyPath_redLEDStateTag = @"redLEDStateTag";
static void * Xkeys3SIVC_KVOContext = @"Xkeys3SIVC_KVOContext";

@interface XK3SIViewController ()

@property (nonatomic) NSInteger greenLEDStateTag;
@property (nonatomic) NSInteger redLEDStateTag;

@property (nonatomic) BOOL kvoRegistered;

@end

// MARK: -

@implementation XK3SIViewController

- (instancetype)initWithXkeysDevice:(id<XkeysDevice>)xkeysDevice {
    
    self = [super initWithNibName:@"XK3SIView" bundle:nil xkeysDevice:xkeysDevice];
    if ( ! self ) {
        return nil;
    }
    
    _greenLEDStateTag = self.xkeys3SIDevice.greenLED.state;
    _redLEDStateTag = self.xkeys3SIDevice.redLED.state;
    
    [self addObserver:self forKeyPath:Xkeys3SIVC_keyPath_greenLEDStateTag options:0 context:Xkeys3SIVC_KVOContext];
    [self addObserver:self forKeyPath:Xkeys3SIVC_keyPath_redLEDStateTag options:0 context:Xkeys3SIVC_KVOContext];
    _kvoRegistered = YES;
    
    return self;
}

- (void)dealloc {
    
    if ( _kvoRegistered ) {
        [self removeObserver:self forKeyPath:Xkeys3SIVC_keyPath_greenLEDStateTag context:Xkeys3SIVC_KVOContext];
        [self removeObserver:self forKeyPath:Xkeys3SIVC_keyPath_redLEDStateTag context:Xkeys3SIVC_KVOContext];
    }
}

// MARK: - NSKeyValueObserving implementation

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    if ( context != Xkeys3SIVC_KVOContext ) {
        return [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
    
    if ( [keyPath isEqualToString:Xkeys3SIVC_keyPath_greenLEDStateTag] ) {
        
        if ( self.xkeys3SIDevice.greenLED.state == self.greenLEDStateTag ) {
            return;
        }
        
        self.xkeys3SIDevice.greenLED.state = self.greenLEDStateTag;
        self.xkeysState.greenLED = self.greenLEDStateTag;
        [self.xkeysView invalidateLEDs];
    }
    else if ( [keyPath isEqualToString:Xkeys3SIVC_keyPath_redLEDStateTag] ) {
        
        if ( self.xkeys3SIDevice.redLED.state == self.redLEDStateTag ) {
            return;
        }
        
        self.xkeys3SIDevice.redLED.state = self.redLEDStateTag;
        self.xkeysState.redLED = self.redLEDStateTag;
        [self.xkeysView invalidateLEDs];
    }
}

// MARK: - XK3SIViewController implementation

- (XkeysState *)createDeviceState {
    return [[XK3SIState alloc] init];
}

- (void)initializeDeviceState {
    
    [super initializeDeviceState];
    
    XkeysState *deviceState = self.xkeysState;
    
    deviceState.greenLED = self.xkeys3SIDevice.greenLED.state;
    deviceState.redLED = self.xkeys3SIDevice.redLED.state;
    
    __weak XK3SIViewController *weakSelf = self;
    
    deviceState.onGreenLEDChange = ^(XkeysLEDState state){
        
        XK3SIViewController *viewController = weakSelf;
        
        if ( viewController.xkeys3SIDevice.greenLED.state == state ) {
            return;
        }
        
        viewController.xkeys3SIDevice.greenLED.state = state;
        viewController.greenLEDStateTag = state;
    };
    
    deviceState.onRedLEDChange = ^(XkeysLEDState state){
        
        XK3SIViewController *viewController = weakSelf;
        
        if ( viewController.xkeys3SIDevice.redLED.state == state ) {
            return;
        }
        
        viewController.xkeys3SIDevice.redLED.state = state;
        viewController.redLEDStateTag = state;
    };
    
    //self.xkeys3SIState.currentTbarPosition = self.xkeys3SIDevice.tbar.currentValue;
    
}

- (void)initializeDeviceCallbacks {
    
    // This contains a few alternatives on how control callbacks can be configured.
    
    __weak XK3SIViewController *weakSelf = self;
    
#if 1 // Uses separate callbacks for buttons and t-bar
    
    [self.xkeys3SIDevice onAnyButtonValueChangePerform:^BOOL(id<XkeysBlueRedButton> button) {
        
        XK3SIViewController *viewController = weakSelf;
        XK3SIState *deviceState = viewController.xkeys3SIState;
        XK3SIView *deviceView = viewController.xkeys3SIView;
        
        NSInteger buttonNumber = button.buttonNumber;
        
        if ( button.currentValue ) {
            [deviceState pressButtonNumber:buttonNumber];
        }
        else {
            [deviceState releaseButtonNumber:buttonNumber];
        }
        //attempt at making generic
        bool validbutton = true;
        long thispid=self.xkeysDevice.productID;
        if (thispid==1089 || thispid==1090 || thispid==1091 || thispid==1250 || thispid==1121 || thispid==1122 || thispid==1123 || thispid==1254) //XK-80/60
        {
            if (buttonNumber>79)validbutton=false;
        }
        else if (thispid==1114 || thispid==1115 || thispid==1116 || thispid==1117 || thispid==1118 || thispid==1119) //XK-68 Jog/Joy
        {
            if (buttonNumber>79)validbutton=false;
        }
        else if (thispid>1324 && thispid<1333) //XKE-64 Jog Tbar
        {
             if (buttonNumber>79)validbutton=false;
        }
        else if (thispid>1126 && thispid<1133) //XK-4/8 Sticks
        {
            if (buttonNumber>32)validbutton=false;
        }
        else if (thispid==1049 || thispid==1050 || thispid==1051 || thispid==1251) //XK-16 Stick
        {
            if (buttonNumber>32)validbutton=false;
        }
        else if (thispid>1126 && thispid<1133) //XK-4/8 Sticks
        {
            if (buttonNumber>32)validbutton=false;
        }
        else if (thispid>1278 && thispid<1285) //XK-32 Rack Mount
        {
            if (buttonNumber>32)validbutton=false;
        }
        
        if (validbutton==true)
        [deviceView invalidateButtonNumber:buttonNumber];
        //see http://xkeys.com/PISupport/DeveloperHIDDataReports.php Input Report for description of each byte
        self.rawDataLabel.stringValue=self.xkeysDevice.rawInput;
        
        return YES;
    }];
    
//    [self.xkeys3SIDevice onTbarValueChangePerform:^BOOL(id<XkeysControl> control) {
//
//       XK3SIViewController *viewController = weakSelf;
//        XK3SIState *deviceState = viewController.xkeys3SIState;
//        XK3SIView *deviceView = viewController.xkeys3SIView;
//
//        deviceState.currentTbarPosition = control.currentValue;
//        [deviceView invalidateTbar];
//        
//        return YES;
//    }];
    
#elif 1 // Uses one callback for all controls
    
    [self.xkeys3SIDevice onAnyControlValueChangePerform:^BOOL(id<XkeysControl> control) {
        
        XK3SIViewController *viewController = weakSelf;
        XK3SIState *deviceState = viewController.xkeys3SIState;
        XK3SIView *deviceView = viewController.xkeys3SIView;
        
        if ( [control conformsToProtocol:@protocol(XkeysBlueRedButton)] ) {
            
            id<XkeysBlueRedButton> button = (id<XkeysBlueRedButton>)control;
            
            NSInteger buttonNumber = button.buttonNumber;
            
            if ( button.currentValue ) {
                [deviceState pressButtonNumber:buttonNumber];
            }
            else {
                [deviceState releaseButtonNumber:buttonNumber];
            }
            
            [deviceView invalidateButtonNumber:buttonNumber];
            //see http://xkeys.com/PISupport/DeveloperHIDDataReports.php Input Report for description of each byte
            self.rawDataLabel.stringValue=self.xkeysDevice.rawInput;
        }
//        else if ( control.maximumValue == 255 ) {
//            
//            deviceState.currentTbarPosition = control.currentValue;
//            [deviceView invalidateTbar];
//        }
        }
        
        return YES;
    }];
    
#elif 1 // Uses one callback for each control
    
    for ( id<XkeysBlueRedButton> button in self.xkeys3SIDevice.buttons ) {
        
        [button onValueChangePerform:^BOOL(id<XkeysControl> control) {
            
            id<XkeysBlueRedButton> button = (id<XkeysBlueRedButton>)control;
            
            XK3SIViewController *viewController = weakSelf;
            XK3SIState *deviceState = viewController.xkeys3SIState;
            XK3SIView *deviceView = viewController.xkeys3SIView;
            
            NSInteger buttonNumber = button.buttonNumber;
            
            if ( button.currentValue ) {
                [deviceState pressButtonNumber:buttonNumber];
            }
            else {
                [deviceState releaseButtonNumber:buttonNumber];
            }
            
            [deviceView invalidateButtonNumber:buttonNumber];
            //see http://xkeys.com/PISupport/DeveloperHIDDataReports.php Input Report for description of each byte
            self.rawDataLabel.stringValue=self.xkeysDevice.rawInput; 
            
            return YES;
        }];
    }
    
//    [self.xkeys3SIDevice.tbar onValueChangePerform:^BOOL(id<XkeysControl> control) {
//
//        XKE124TBarViewController *viewController = weakSelf;
//        XKE124TBarState *deviceState = viewController.xkeys124State;
//        XKE124TBarView *deviceView = viewController.xkeys124View;
//
//        deviceState.currentTbarPosition = control.currentValue;
//        [deviceView invalidateTbar];
//
//        return YES;
//    }];


#endif
}

- (id<Xkeys3SI>)xkeys3SIDevice {
    
    NSAssert([self.xkeysDevice conformsToProtocol:@protocol(Xkeys3SI)], @"");
    if ( ! [self.xkeysDevice conformsToProtocol:@protocol(Xkeys3SI)] ) {
        return nil;
    }
    
    return (id<Xkeys3SI>)self.xkeysDevice;
}

- (XK3SIState *)xkeys3SIState {
    
    NSAssert([self.xkeysState isKindOfClass:[XK3SIState class]], @"");
    if ( ! [self.xkeysState isKindOfClass:[XK3SIState class]] ) {
        return nil;
    }
    
    return (XK3SIState *)self.xkeysState;
}

- (XK3SIView *)xkeys3SIView {
    
    NSAssert([self.xkeysView isKindOfClass:[XK3SIView class]], @"");
    if ( ! [self.xkeysView isKindOfClass:[XK3SIView class]] ) {
        return nil;
    }
    
    return (XK3SIView *)self.xkeysView;
}

@end
