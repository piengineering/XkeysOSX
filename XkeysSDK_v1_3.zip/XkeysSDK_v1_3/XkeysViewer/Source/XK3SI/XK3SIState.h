//
//  XK3SIState.h
//  XkeysViewer
//
//  Encapsulates the state of an XK-3 Switch Interface.
//
//  Created by Ken Heglund on 10/24/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

@import Foundation;

#import "XkeysState.h"

@interface XK3SIState : XkeysState

@property (nonatomic) NSInteger currentTbarPosition;

@property (nonatomic, readonly) NSInteger minTbarPosition;
@property (nonatomic, readonly) NSInteger maxTbarPosition;

- (instancetype)init NS_DESIGNATED_INITIALIZER;
- (instancetype)initWithButtonCount:(NSInteger)numberOfButtons NS_UNAVAILABLE;

@end
