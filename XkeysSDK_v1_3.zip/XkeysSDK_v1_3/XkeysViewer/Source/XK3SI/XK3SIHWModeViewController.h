//
//  XK3SIHWModeViewController.h
//  XkeysViewer
//
//  Coordinates the UI for an XK-3 Switch Interface with PID #2 (1222) or #3 (1223).
//
//  Created by Ken Heglund on 11/10/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import "XK3SIViewController.h"

@interface XK3SIHWModeViewController : XK3SIViewController

@end
