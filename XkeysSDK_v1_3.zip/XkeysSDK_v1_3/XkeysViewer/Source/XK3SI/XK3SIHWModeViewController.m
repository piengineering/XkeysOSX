//
//  XK3SIHWModeViewController.m
//  XkeysViewer
//
//  Created by Ken Heglund on 11/10/17.
//  Copyright © 2017 P.I. Engineering. All rights reserved.
//

#import "XK3SIHWModeViewController.h"

@interface XK3SIHWModeViewController ()

@end

@implementation XK3SIHWModeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.unitIDTextField.enabled = NO; //can set unitid in hardware mode just can't read it
    self.unitIDTextField.stringValue = @"";
    self.outputbytesTextField.stringValue = @"B3 07 02";
}

@end
